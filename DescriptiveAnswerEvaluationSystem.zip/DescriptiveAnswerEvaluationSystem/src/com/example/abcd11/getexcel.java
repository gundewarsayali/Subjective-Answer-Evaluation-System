package com.example.abcd11;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * Servlet implementation class getexcel
 */
@WebServlet("/getexcel")
public class getexcel extends HttpServlet {
	private static final long serialVersionUID = 1L;
       Connection con;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getexcel() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw=response.getWriter();
		int testid=0;
		int mark=0;
		String question="",option1="",option2="",option3="",option4="";
	  
		try{
			Class.forName("com.mysql.jdbc.Driver");
		    con= DriverManager.getConnection("jdbc:mysql://localhost/DescriptiveAnswer","root","root");
		 
			
			 
	      String[] datafound= new String[1500];
	      XSSFRow row;
	      FileInputStream fis = new FileInputStream( new File("D:/QuestionData.xlsx")); 
	      XSSFWorkbook workbook = new XSSFWorkbook(fis);
	      XSSFSheet spreadsheet = workbook.getSheetAt(0);
	      Iterator < Row > rowIterator = spreadsheet.iterator();
	      int count=0;
	      while (rowIterator.hasNext()) 
	      {
	         row = (XSSFRow) rowIterator.next();
	         Iterator < Cell > cellIterator = row.cellIterator();
	         int count22=0;
	         
	         while ( cellIterator.hasNext()) 
	         {
	        	 
	            Cell cell = cellIterator.next();
	            
	           
	            if(cell.getColumnIndex()==0){
	            	
	            	pw.println(cell.getStringCellValue());
	            	question=""+cell.getStringCellValue();
	            	
	            }
	           
	            if(cell.getColumnIndex()==1){
	            	
	            	pw.println(cell.getNumericCellValue());
	            	float val=Float.parseFloat(""+cell.getNumericCellValue());
	            	 testid=(int)val;
	            	
	            }
	            
	            if(cell.getColumnIndex()==2){
	            	
	            	pw.println(cell.getStringCellValue());
	            	option1=""+cell.getStringCellValue();
	            	
	            }
	            if(cell.getColumnIndex()==3){
	            	
	            	pw.println(cell.getStringCellValue());
	            	option2=""+cell.getStringCellValue();
	            	
	            }
	            if(cell.getColumnIndex()==4){
	            	
	            	pw.println(cell.getStringCellValue());
	            	option3=""+cell.getStringCellValue();
	            	
	            }
	            
	            if(cell.getColumnIndex()==5){
	            	
	            	pw.println(cell.getStringCellValue());
	            	option4=""+cell.getStringCellValue();
	            	
	            }
	            
	            if(cell.getColumnIndex()==6){
	            	
	            	pw.println(cell.getNumericCellValue());
	            	float val1=Float.parseFloat(""+cell.getNumericCellValue());
	            	mark=(int)val1;
	            	
	            }
	            
	           
	            
	            
	            
	            
	         }
	        
	      }  
	      PreparedStatement prst=con.prepareStatement("insert into questions(TestId,Question,Option1,Option2,Option3,Option4,Answer,Mark) values(?,?,?,?,?,?,?,?) ");
          prst.setString(1,""+testid);
          prst.setString(2, question);
          prst.setString(3,option1);
          prst.setString(4, option2);
          prst.setString(5, option3);
          prst.setString(6, option4);
          prst.setString(7, " ");
          prst.setString(8, ""+mark);
          prst.executeUpdate();
		}catch(Exception e){
			pw.println(""+e);
		}
	      }
     
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
